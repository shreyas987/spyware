
Task 4: 
	Create a customized video (of about 20sec using a set of images) and write down a key logger; both in python.
	
	--This contains 2 codes client4a.py and client4b.py pertaining to the two tasks in this question above.
	--This folder also contains another folder called /images. It contains multiple images which will be used for creating the video.
	--It contains pyxhook.py which is a readily available library which can be used for developing a Keylogger code.
	--client4a.py code uses the images present in the /images folder and creates a video, which is stored in current folder.
	--client4b.py code uses pyxhook.py as a library to generate a keylogger file. To stop the keyloggeer code, press ` (below ESC key)
	
	pyxhook package may have to installed in the system before running
	

Commands:
	open terminal >> python client4a.py	// This code makes a custom video using images
	open terminal >> python client4b.py   //Press ` (below ESC key to stop the keylogger code) -- This is the keylogger code
	
	
