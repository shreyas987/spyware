Each task has its own folder and the codes are present inside these folders along with their instructions and readme
