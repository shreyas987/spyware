
Task 6: 
	Spread the spyware using the server to the client computer (assume the victim has all the required packages installed to run your 		program).
Task 7: 
	The client should run the spyware and return the keystroke history of last 2 mins.
	
	--Task6 and Task7 have been coded together.
	Server folder
		-- It contains /images folder containing images needed for creating custom video.
		-- server67.py code creates a custom video using /images and hides the keylogger code in the video frames.
		-- When a client connects to the server it sends the video with keylogger to the client.
		-- Keylogger.py is slightly modified to be able to connect back to the server after being extracted on client side.
		-- After client server interaction, video file and keylogger's log file(KL.txt) will be created in server folder.
	Client folder
		-- It contains client67.py and extract.py codes.
		-- client67.py connects to the server (server67.py) and receives a video file which will be stored in client folder.
		-- It later automatically runs, extract.py code which will extract hidden keylogger code from received video frames.
		-- hiddenkeylogger.py will be automatically executed which records the key strokes for 50 seconds
			To increase keylogger time to 120 seconds (2 mins)
			This can be changed by making it time.sleep(120) in keylogger.py (present in server folder).
			Also compulsarily will have to extend the server timeout value in server67.py as it has to wait to receive the file.
		--This recorded keystrokes are stored in KL.txt on client folder which is also sent back to server.
		-- After client server interaction, video file hiddenkeylogger.py and KL.txt will be created in client folder.

NOTE : The keylogger will run for 120secs(2 minutes). Please wait till the time elapses.

Commands:
	server folder --> open terminal >> python server67.py
	
	client folder --> open terminal >> python client67.py   // enter key strokes when client starts recording key strokes. It will later 									   send the recorded keys back to server automatically. At last check KL.txt 									   file on server side.
