# first of all import the socket library 
import socket	
import hashlib
import thread
import time


#---------------------------------------------------------------------
# thread function 
def threaded(c): 

	with open('received_file'+str(time.time()), 'wb') as f:
	    print 'file opened'
	    print('receiving data...')
	    while True:
		data = c.recv(1024)
		print('data=%s', (data))
		if not data:
		    break
		# write data to a file
		f.write(data)

	f.close()
	print('Successful transmission!!')
	print(c.recv(1024))

		
#---------------------------------------------------------------------
#MAIN 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)		 
print ("Socket successfully created")
s.setsockopt( socket.SOL_SOCKET, socket.SO_REUSEADDR , 1)
s.setblocking(0)
s.settimeout(40)
#Any port number
port = 1234				

s.bind(('', port))		 
print ("socket binded to %s" %(port)) 

# socket into listening mode 
s.listen(20)	 
print ("socket is listening")
count = 0
while count < 2: 
	
	# Establish connection with client. 
	c, (ip,port) = s.accept()	 
	print ('Got connection from', str(ip) + str(port))
	count = count +1
	threaded(c)
	
print("\nRecieved both audio and video files")	
s.shutdown(1)
s.close()
		
		
