import socket                  
import hashlib
import random



#MAIN -- Creating 2 connections and send each file during a connection

s = socket.socket()             
host = ''     			
port = 1234                    
	
s.connect((host, port))
print('connected..')
## Sending audio file
filename='./audio.mp3'
f = open(filename,'rb')
l = f.read(1024)
while (l):
   s.send(l)
   print('Sent ',repr(l))
   l = f.read(1024)
f.close()
print('Done sending Audio')
s.send("DONE SENDING AUDIO")
s.close()
#Sending Video file
s = socket.socket()             
host = ''     			
port = 1234                    
	
s.connect((host, port))
print('connected..')

filename='./video.mp4'
f = open(filename,'rb')
l = f.read(1024)
while (l):
   s.send(l)
   print('Sent ',repr(l))
   l = f.read(1024)
f.close()
print('\nDone sending both audio and Video')
s.send("DONE SENDING BOTH AUDIO AND VIDEO")
s.close()

