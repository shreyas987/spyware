
Task 1: 
	Develop a server that can receive and store appropriately a video and a audio file from a remote client
	
Client folder:
	Contains client1.py which will transfer a audio and a video file to the server.
	Also contains a sample audio.mp3 and video.mp4 file
	
	NOTE --->The filename of the file to be sent to the server should be mentioned in the client1.py code.
	
Server folder:
	Contains the server1.py code which will receive the file from the client and store it in its own directory
	

Commands:
	server folder -> open terminal >> python server1.py
	Client folder -> open terminal >> python client1.py
