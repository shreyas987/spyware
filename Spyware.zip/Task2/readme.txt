
Task 2: 
	Develop a client that can search a web camera in hosts computer and record video (in .avi or .mp4 format)
	
	--This contains client2.py code which will access the webcamera of the host and record a video.
	--Video will be stored in the current folder.
	--Recording can be stopped by pressing 'X'
	

Commands:
	open terminal >> python client2.py
	
	NOTE -- Press X to terminate
