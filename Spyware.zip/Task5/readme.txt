
Task 5: 
	Create a spyware by applying steganography where you need to hide the keylogger within the customized video
	
	--This contains 2 codes client5.py and Keylogger.py
	--Keylogger.py is the same code which is developed for Task4. I have not included pyxhook.py code in this folder as we are not 		  running keylogger code here.
	--This also contains a folder /images which contains image required for creating a video.
	--client5.py will create a custom video using images in /images folder and embed the Keylogger code within the video frame.
	--It later extracts the keylogger code from the video frames and prints it on the terminal.


Commands:
	open terminal >> python client5.py
	
