
Task 3: 
	Client program should also search for a speaker and record audio (in .mp3 or any other format)
	
	--This contains client3.py code which will access the microphone of the host and record an audio.
	--Audio will be stored in the current folder.
	--Recording will stop after 20 seconds. The time can be adjusted in the code.
	

Commands:
	open terminal >> python client3.py
	
	
